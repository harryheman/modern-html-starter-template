import { createTimer } from './js/create-timer'

import './styles/index.scss'

createTimer()
