export const assets = [
  'All Meta & Link Tags',
  'HTML5 Tags & CSS3 Props',
  'CSS & JavaScript Modules',
  'Service Worker',
  'manifest.json',
  'AMP Project',
  'Webpack Project',
  'Express.js Server',
  'All Security Headers',
  'netlify.toml',
  'robots.txt',
  'sitemap.xml',
  'browserconfig.xml',
  '.gitignore',
  'Error 404 Page',
  'And More'
]
