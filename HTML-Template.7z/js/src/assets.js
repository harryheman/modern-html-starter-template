export const assets = [
  'All Meta & Link Tags',
  'HTML5 Tags Example',
  'CSS3 Props Example',
  'CSS Modules Example',
  'JavaScript Modules Example',
  'manifest.json',
  'Sevice Worker Example',
  'robots.txt',
  'sitemap.xml',
  'browserconfig.xml',
  '.gitignore',
  'Local Express.js Server Example',
  'Error 404 Page Example',
  'README.md',
  'And More'
]
