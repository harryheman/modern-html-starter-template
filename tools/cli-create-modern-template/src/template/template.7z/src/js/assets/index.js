export const assets = [
  'All Meta & Link Tags',
  'HTML5 Tags & CSS3 Props',
  'CSS & JavaScript Modules',
  'Service Worker',
  'manifest.json',
  'AMP Project',
  'All Security Headers',
  'Express.js Server',
  'netlify.toml',
  'robots.txt',
  'sitemap.xml',
  'browserconfig.xml',
  '.gitignore',
  'README.md',
  'Error 404 Page',
  'And More'
]
